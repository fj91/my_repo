package com.diplomado.navigation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val txtScreen: EditText = findViewById(R.id.editTextNumbers)

        val buttonResult: Button = findViewById(R.id.buttonEqual)
        val buttonPlus: Button = findViewById(R.id.buttonPlus)
        val buttonMinus: Button = findViewById(R.id.buttonRes)
        val buttonMulti: Button = findViewById(R.id.buttonPro)
        val buttonDiv: Button = findViewById(R.id.buttonDiv)

        val val1:Int = 0
        val val2:Int = 0

        buttonResult.setOnClickListener {
            val number1 = txtNumber1.text.toString().toInt()
            val number2 = txtNumber2.text.toString().toInt()
            val sum = number1 + number2

            Toast.makeText(this, "The sum is: $sum", Toast.LENGTH_SHORT).show()
        }

        buttonPlus.setOnClickListener {
            if (txtScreen)
            val number1 = txtNumber1.text.toString().toInt()
            val number2 = txtNumber2.text.toString().toInt()
            val sum = number1 + number2

        }

    }
}