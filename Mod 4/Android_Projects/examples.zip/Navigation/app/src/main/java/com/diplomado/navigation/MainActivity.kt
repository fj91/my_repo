package com.diplomado.navigation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val goButton: Button = findViewById(R.id.buttonGo)
        val nameText: EditText = findViewById(R.id.editTextName)
        val lastNameText: EditText = findViewById(R.id.editTextLastName)

        goButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("NAME", nameText.text.toString())
            intent.putExtra("LASTNAME", lastNameText.text.toString())
            startActivity(intent)
        }

    }
}