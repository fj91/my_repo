package com.diplomado.mysumapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val number1: EditText = findViewById(R.id.textViewNumber1)
        val number2: EditText = findViewById(R.id.textViewNumber2)
        val button: Button = findViewById(R.id.button)


        button.setOnClickListener {
            val num1 = number1.text.toString().toInt()
            val num2 = number2.text.toString().toInt()
            val sum = num1 + num2

            Toast.makeText(this, "La suma es: $sum", Toast.LENGTH_LONG).show()
        }

    }
}