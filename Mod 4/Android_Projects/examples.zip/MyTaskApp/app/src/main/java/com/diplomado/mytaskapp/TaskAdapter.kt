package com.diplomado.mytaskapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class TaskAdapter(context: Context) : ArrayAdapter<Task>(context, 0) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            view = inflater.inflate(R.layout.list_item, parent, false)!!
        }

        val taskTitle : TextView = view.findViewById(R.id.title)
        val task = getItem(position)

        taskTitle.text = task?.name

        return view
    }
}