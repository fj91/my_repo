package com.diplomado.mytaskapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: TaskAdapter
    var taskList: MutableList<Task?> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView: ListView = findViewById(R.id.task_list)
        val addButton: Button = findViewById(R.id.add_button)


        val bundle = intent.extras
        val title = bundle?.getString("TASK_TITLE").toString()
        val description = bundle?.getString("TASK_DESC").toString()

        adapter = TaskAdapter(this)
        adapter.add(Task(title,description))
        listView.adapter = adapter



        addButton.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            for (i in 0 until adapter.count) {
                taskList.add(adapter.getItem(i))
            }
            intent.putExtra("TASKS", taskList)
            startActivity(intent)
        }

    }


}