package com.diplomado.mytaskapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast

class AddTaskActivity : AppCompatActivity() {
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)
        adapter = TaskAdapter(this)
        val title: EditText = findViewById(R.id.task_title)
        val desc: EditText = findViewById(R.id.task_desc)
        val submitTask: Button = findViewById(R.id.submit_task)

        submitTask.setOnClickListener {
            val field1 = title.text.toString()
            val field2 = desc.text.toString()


            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("TASK_TITLE", field1 )
            intent.putExtra("TASK_DESC", field2 )
            startActivity(intent)

            /*val task = Task(field1,field2)
            adapter.add(task)*/

            /*Toast.makeText(this, "Se ha agregado la tarea nueva", Toast.LENGTH_SHORT)
                .show()

            title.setText("")
            desc.setText("")*/
        }


    }
}