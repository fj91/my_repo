package com.diplomado.mytaskapp

data class Task(
    var name: String,
    var description: String) : java.io.Serializable