package cl.puc.ing.gallerytest

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.widget.Button
import android.widget.DatePicker
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.datepicker.MaterialDatePicker

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.appBarLayout)
        setSupportActionBar(toolbar)


        val list = mutableListOf("Item 1", "Item 2", "Item 3")
        val itemListView: RecyclerView = findViewById(R.id.itemList)
        itemListView.layoutManager = GridLayoutManager(this, 2)
        itemListView.adapter = ItemAdapter(list)

        val mainButton: Button = findViewById(R.id.mainButton)
        mainButton.setOnClickListener {
            val datePicker = MaterialDatePicker.Builder
                .datePicker()
                .setTitleText("Select a date").build()
            datePicker.show(supportFragmentManager, "tag")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater

        inflater.inflate(R.menu.menu, menu)
        return true
    }
}