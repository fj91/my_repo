package com.example.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val txtNumber1: EditText = findViewById(R.id.txtNumber1)
        val txtNumber2: EditText = findViewById(R.id.txtNumber2)
        val button: Button = findViewById(R.id.buttonAction)

        button.setOnClickListener {
            val number1 = txtNumber1.text.toString().toInt()
            val number2 = txtNumber2.text.toString().toInt()
            val sum = number1 + number2

            Toast.makeText(this, "The sum is: $sum", Toast.LENGTH_LONG).show()
        }
    }
}