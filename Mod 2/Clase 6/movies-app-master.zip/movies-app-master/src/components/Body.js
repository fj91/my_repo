import { styled } from "@mui/material/styles";

export const Body = styled("div")`
  padding-top: 64px;
  max-width: 900px;
  margin: auto;
`;
