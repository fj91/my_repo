function isNumber(x) {
    /* para ayudar en la validación */
    return !isNaN(parseInt(x));
}
function validar() {
    /* aqui escribir el codigo de la funcion validar
       debe retornar true si la validacion pasa y false si no pasa
       si la validacion falla debe cambiar tambien la cara a una triste
    */
}

