import styled from "@emotion/native";

export const Body = styled.View`
  flex: 1;
`;

export const ScrollBody = styled.ScrollView`
  flex: 1;
`;
